package com.infosys.infytel.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.infytel.entity.FriendFamily;

public interface FriendandFamilyRepo extends JpaRepository<FriendFamily, Long> {

	List<FriendFamily> getByPhoneNo(Long phoneNo );
}
